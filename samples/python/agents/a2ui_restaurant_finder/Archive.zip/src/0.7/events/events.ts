/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import { BaseEventDetail } from "./base";
import * as GULF from "./gulf";

export class StateEvent extends Event {
  constructor(
    public readonly detail: StateEventDetailMap[keyof StateEventDetailMap]
  ) {
    super(detail.eventType, { bubbles: true, composed: true });
  }
}


type EnforceEventTypeMatch<T> = {
  [K in keyof T]: T[K] extends BaseEventDetail<string>
  ? T[K]["eventType"] extends K
  ? T[K]
  : "eventType property must match key"
  : "Event detail must extend BaseEventDetail";
};

export type StateEventDetailMap = EnforceEventTypeMatch<{
  "gulf.action": GULF.GulfActionDetail;
}>;