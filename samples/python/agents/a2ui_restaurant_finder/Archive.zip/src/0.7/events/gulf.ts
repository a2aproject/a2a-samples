/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import { Action } from "../types/component-update";
import { BaseEventDetail } from "./base";

// This is just the data structure for an action.
export interface GulfAction {
  readonly action: Action;
  readonly dataPrefix?: string;
}


export interface GulfActionDetail extends BaseEventDetail<"gulf.action"> {
  readonly action: Action;
  readonly dataPrefix?: string;
}

export interface GulfInput {
  readonly id: string;
  readonly value: string | number | boolean;
}

export type GulfEvent = GulfAction | GulfInput;