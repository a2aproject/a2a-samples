/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import "./ui/ui.js";
import { DataModel } from "./data/model.js";
import { LitElement, html, css, nothing } from "lit";
import { customElement, state } from "lit/decorators.js";
import { markdown } from "./directives/markdown.js";
import { icons } from "./utils/icons.js";
import { StateEvent } from "./events/events.js";
import { Part } from "@a2a-js/sdk";

@customElement("gulf-main")
export class GulfMain extends LitElement {
  static styles = [
    icons,
    css`
      :host {
        display: block;
        width: 100%;
        font-family: var(--font-family);
      }

      form {
        display: flex;
        gap: 16px;
        align-items: center;
        padding: 16px 0;

        & > input {
          display: block;
          flex: 1;
          border-radius: 32px;
          padding: 16px 24px;
          border: 1px solid #ccc;
          font-size: 16px;
        }

        & > button {
          background: #222;
          color: #fff;
          border: none;
          padding: 8px 16px;
          border-radius: 32px;
          opacity: 0.5;

          &:not([disabled]) {
            cursor: pointer;
            opacity: 1;
          }
        }
      }

      hr {
        border: none;
        height: 1px;
        background: #ccc;
      }

      gulf-root {
        margin: 32px 0;
      }

      .rotate {
        animation: rotate 1s linear infinite;
      }

      .pending {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;

        & .g-icon {
          margin-right: 8px;
        }
      }

      details {
        font-size: 14px;

        & summary {
          list-style: none;
          cursor: pointer;

          &::-webkit-details-marker {
            display: none;
          }
        }
      }

      @keyframes rotate {
        from {
          rotate: 0deg;
        }

        to {
          rotate: 360deg;
        }
      }
    `,
  ];

  @state()
  accessor #data: {
    rawText?: string;
    model?: DataModel;
  } | null = null;

  @state()
  accessor #fetching = false;

  @state()
  accessor #error: string | null = null;

  async #onGulfAction(evt: Event) {
    const { detail } = evt as StateEvent;
    if (detail.eventType !== "gulf.action") return;

    console.log("[gulf-main] @gulfaction event FIRED. Event detail:", detail);
    try {
      if (!this.#data?.model) {
        console.error("[gulf-main] ERROR: No data model found.");
        return;
      }

      const { action, dataPrefix } = detail;
      console.log(
        "[gulf-main] Action:",
        action.action,
        "DataPrefix:",
        dataPrefix
      );

      if (!action.context) {
        console.error("[gulf-main] ERROR: No context on action.");
        return;
      }

      const payload: Record<string, unknown> = {};
      console.log("[gulf-main] Resolving payload...");
      for (const item of action.context) {
        if (item.value.path) {
          payload[item.key] = await this.#data.model.getDataProperty(
            item.value.path,
            dataPrefix
          );
        } else if (item.value.literalBoolean) {
          payload[item.key] = item.value.literalBoolean;
        } else if (item.value.literalNumber) {
          payload[item.key] = item.value.literalNumber;
        } else if (item.value.literalString) {
          payload[item.key] = item.value.literalString;
        }
        console.log(`[gulf-main]   Resolved ${item.key}:`, payload[item.key]);
      }

      const message = { action: action.action, context: payload };

      console.log(
        "[gulf-main] PAYLOAD RESOLVED. Sending to /a2a:",
        message
      );

      this.#fetching = true;
      const response = await fetch("/a2a", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(message),
      });
      this.#fetching = false;

      console.log("[gulf-main] Received response from /a2a:", response.status);

      const itemsOrError = (await response.json()) as
        | Part[]
        | { error: string };

      if (response.ok) {
        console.log(
          "[gulf-main] Response OK. Processing...",
          itemsOrError
        );
        this.#processResponse(itemsOrError as Part[]);
      } else {
        console.error("[gulf-main] Response ERROR:", itemsOrError);
        this.#error =
          (itemsOrError as { error: string }).error ||
          "An unknown error occurred.";
      }
    } catch (err) {
      console.error("[gulf-main] FATAL ERROR in @gulfaction handler:", err);
      this.#error = (err as Error).message;
      this.#fetching = false;
    }
  }

  connectedCallback(): void {
    super.connectedCallback();
    window.addEventListener("gulf.action", this.#onGulfAction.bind(this));
  }

  disconnectedCallback(): void {
    super.disconnectedCallback();
    window.removeEventListener(
      "gulf.action",
      this.#onGulfAction.bind(this)
    );
  }

  #processResponse(items: Part[]) {
    if (Array.isArray(items)) {
      for (const item of items) {
        if (item.kind === "text") {
          this.#data = this.#data ?? {};
          this.#data.rawText = item.text;
        } else if (item.kind === "data") {
          this.#data = this.#data ?? {};
          if (item.data.gulfMessages) {
            if (Array.isArray(item.data.gulfMessages)) {
              console.log(
                "[gulf-main] Received new UI model, creating DataModel..."
              );

              this.#data.model = new DataModel(item.data.gulfMessages);

              (window as unknown as { __model: DataModel }).__model =
                this.#data.model;
            } else {
              this.#error = "Unable to retrieve.";
            }
          } else if (item.data.error) {
            if (typeof item.data.error === "string") {
              this.#error = item.data.error;
            } else {
              this.#error = JSON.stringify(item.data.error);
            }
          }
        }
      }
    } else {
      this.#error = "Unable to retrieve.";
    }
  }

  #renderData() {
    if (!this.#data) {
      return nothing;
    }

    return [
      this.#data.model
        ? html`<gulf-root
              id=${this.#data.model.data.root.id}
              .model=${this.#data.model}
              .components=${[this.#data.model.data.root]}
            ></gulf-root>
            <hr />` 
        : nothing,

      this.#data.rawText
        ? html`<details>
            <summary>Text response</summary>
            ${markdown(this.#data.rawText)}
          </details>`
        : nothing,
    ];
  }

  render() {
    return [
      this.#data
        ? nothing
        : html`<form
            @submit=${async (evt: Event) => {
            evt.preventDefault();
            if (!(evt.target instanceof HTMLFormElement)) {
              return;
            }

            const data = new FormData(evt.target);
            const body = data.get("body") ?? null;
            if (!body) {
              return;
            }

            console.log("[gulf-main] Sending text query to /a2a:", body);

            this.#fetching = true;
            const response = await fetch("/a2a", { method: "POST", body });
            this.#fetching = false;

            const itemsOrError = (await response.json()) as
              | Part[]
              | { error: string };

            if (response.ok) {
              this.#processResponse(itemsOrError as Part[]);
            } else {
              this.#error =
                (itemsOrError as { error: string }).error ||
                "An unknown error occurred.";
            }
          }}
          >
            <input
              required
              value="Show me a list of image cards with information about Italian restaurants in downtown New York."
              autocomplete="off"
              id="body"
              name="body"
              type="text"
              ?disabled=${this.#fetching}
            />
            <button type="submit" ?disabled=${this.#fetching}>Send</button>
          </form>`,
      this.#fetching
        ? html` <div class="pending">
            <span class="g-icon filled-heavy rotate">progress_activity</span>
            Awaiting response...
          </div>`
        : this.#data
          ? this.#renderData()
          : nothing,
      this.#error ? html`${this.#error}` : nothing,
    ];
  }
}

const main = new GulfMain();
document.body.appendChild(main);